#!/bin/sh
# سند | Sanad — التشغيل على لينكس وأندرويد (Termux): ./start-sanad-linux.sh
exec sh "$(dirname "$0")/scripts/start.sh" "$@"
