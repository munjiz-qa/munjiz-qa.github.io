#!/bin/sh
# سند | Sanad — انقر نقراً مزدوجاً للتشغيل على ماك
exec sh "$(dirname "$0")/scripts/start.sh" "$@"
