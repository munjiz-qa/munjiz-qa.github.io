#!/usr/bin/env node
/* =====================================================================
   سند | Sanad — الخادم المحمول
   خادم واحد بلا أي مكتبات خارجية (Node.js 18+). يقدّم التطبيق ويحفظ البيانات
   ويدير الحسابات ويتصل بـ Claude بمفتاح المدير. يعمل على ويندوز وماك ولينكس
   والخوادم وأندرويد (Termux) وداخل Docker.
   ===================================================================== */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const Assistant = require('./public/assistant.js');

const VERSION = '1.1.0';
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.resolve(process.env.SANAD_DATA || path.join(ROOT, 'data'));
const PORT = Number(process.env.PORT || process.env.SANAD_PORT || 8787);
const HOST = process.env.SANAD_HOST || '0.0.0.0';
const AI_BASE = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, '');
const MODELS = { opus: 'claude-opus-5-5', sonnet: 'claude-sonnet-5-5', haiku: 'claude-haiku-5-5' };
const DOC_MAX = 256 * 1024, DB_MAX = 50 * 1024 * 1024;

fs.mkdirSync(DATA, { recursive: true });

/* ---------- storage (JSON files, atomic writes) ---------- */
const file = n => path.join(DATA, n);
function readJSON(n, d) { try { return JSON.parse(fs.readFileSync(file(n), 'utf8')); } catch { return d; } }
const pending = new Map();
function writeJSON(n, v) {
  pending.set(n, v);
  if (pending.size === 1) setImmediate(flush);
}
function flush() {
  for (const [n, v] of pending) {
    const tmp = file(n + '.tmp');
    fs.writeFileSync(tmp, JSON.stringify(v), { mode: 0o600 });
    fs.renameSync(tmp, file(n));
  }
  pending.clear();
}
process.on('exit', flush);
for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => { flush(); process.exit(0); });

const cfg = Object.assign({
  apiKey: '', model: 'sonnet', visitorChat: true, registration: true,
  limits: { visitor: 20, client: 60, admin: 600 }, secret: crypto.randomBytes(32).toString('hex')
}, readJSON('config.json', {}));
const users = readJSON('users.json', {});          // id -> user
const sessions = readJSON('sessions.json', {});    // token -> { uid, exp }
const db = readJSON('db.json', {});                // path -> doc
const saveCfg = () => writeJSON('config.json', cfg);
const saveUsers = () => writeJSON('users.json', users);
const saveSessions = () => writeJSON('sessions.json', sessions);
const saveDb = () => writeJSON('db.json', db);
saveCfg();

const hasAdmin = () => Object.values(users).some(u => u.role === 'admin');
let setupCode = '';
function ensureSetupCode() {
  if (hasAdmin()) { for (const n of ['setup-code.txt', 'setup-code.json']) try { fs.unlinkSync(file(n)); } catch {} setupCode = ''; return; }
  setupCode = (readJSON('setup-code.json', null) || {}).code || crypto.randomBytes(4).toString('hex').toUpperCase();
  fs.writeFileSync(file('setup-code.json'), JSON.stringify({ code: setupCode }));
  fs.writeFileSync(file('setup-code.txt'), setupCode + '\n');
}
ensureSetupCode();

/* ---------- normalisation (same formats as the app) ---------- */
const AR = '٠١٢٣٤٥٦٧٨٩', FA = '۰۱۲۳۴۵۶۷۸۹';
const toLatin = s => String(s || '').replace(/[٠-٩۰-۹]/g, c => String(AR.includes(c) ? AR.indexOf(c) : FA.indexOf(c)));
function normPhone(p) {
  let d = toLatin(p).replace(/[^\d+]/g, '');
  if (!d) return '';
  if (d.startsWith('+')) d = d.slice(1); else if (d.startsWith('00')) d = d.slice(2);
  else if (d.startsWith('05') && d.length === 10) d = '966' + d.slice(1);
  else if (d.startsWith('5') && d.length === 9) d = '966' + d;
  else if (/^[3567]\d{7}$/.test(d)) d = '974' + d;
  if (d.startsWith('966') && d.length === 12) return `+966 ${d.slice(3, 5)} ${d.slice(5, 8)} ${d.slice(8)}`;
  if (d.startsWith('974') && d.length === 11) return `+974 ${d.slice(3, 7)} ${d.slice(7)}`;
  return '+' + d;
}
const normEmail = e => String(e || '').trim().toLowerCase();
const normName = n => String(n || '').replace(/\s+/g, ' ').trim().slice(0, 80);
const digits = p => toLatin(p).replace(/\D/g, '');

/* ---------- auth ---------- */
function hashPw(pw, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(String(pw), salt, 64).toString('hex') };
}
function checkPw(u, pw) {
  const h = crypto.scryptSync(String(pw), u.salt, 64);
  return crypto.timingSafeEqual(h, Buffer.from(u.hash, 'hex'));
}
function findUser(login) {
  const e = normEmail(login), d = digits(login);
  return Object.values(users).find(u => (e && u.email === e) || (d.length >= 8 && digits(u.phone).endsWith(d.slice(-8))));
}
function cookies(req) {
  const o = {}; (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return o;
}
function sessionUser(req) {
  const t = cookies(req).sanad_sid; const s = t && sessions[t];
  if (!s || s.exp < Date.now() || !users[s.uid]) return null;
  return users[s.uid];
}
function startSession(res, req, u) {
  const t = crypto.randomBytes(32).toString('hex');
  sessions[t] = { uid: u.id, exp: Date.now() + 30 * 864e5 };
  for (const [k, v] of Object.entries(sessions)) if (v.exp < Date.now()) delete sessions[k];
  saveSessions();
  const secure = req.headers['x-forwarded-proto'] === 'https' || req.socket.encrypted ? '; Secure' : '';
  res.setHeader('Set-Cookie', `sanad_sid=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30 * 86400}${secure}`);
}
const publicUser = u => u && ({ id: u.id, name: u.name, phone: u.phone, email: u.email, role: u.role, super: !!u.super, defaultPassword: !!u.seedPw, createdAt: u.createdAt });

/* ---------- default accounts (first run) ----------
   عند أول تشغيل يُنشأ «المدير الشامل» و«العميل الافتراضي» وبيانات نشاط جاهزة، فيعمل سند فوراً
   دون أي إعداد. كلمات المرور من SANAD_ADMIN_PASSWORD / SANAD_CLIENT_PASSWORD إن وُجدت،
   وإلا وُلّدت عشوائية عند أول تشغيل وطُبعت في الطرفية وفي data/default-accounts.txt.
   SANAD_SEED=0 يعطّل ذلك ويعيد صفحة الإعداد الأول. */
const freshPw = () => 'Sanad-' + crypto.randomBytes(9).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, 12);
const DEFAULTS = {
  admin: { name: 'المدير العام', email: 'admin@sanad.local', phone: '+974 5160 0498', password: process.env.SANAD_ADMIN_PASSWORD || freshPw() },
  client: { name: 'عميل سند', email: 'client@sanad.local', phone: '+974 5000 0001', password: process.env.SANAD_CLIENT_PASSWORD || freshPw() }
};
const SITE_SEED = {
  name: 'سند من منجز', tagline: 'وكيلك التنفيذي الذكي لإدارة العملاء والمواعيد', city: 'الدوحة',
  phone: '+974 5160 0498', email: 'munijizqa@gmail.com',
  about: 'سند من منجز ينظّم عملاءك ومواعيدك وطلباتك في مكان واحد، ويرد على أسئلتهم على مدار الساعة.',
  services: [{ name: 'استشارة أولية', duration: 30, price: '150 ر.ق' }, { name: 'إعداد سند لنشاطك', duration: 60, price: '900 ر.ق' }, { name: 'جلسة متابعة', duration: 45, price: '300 ر.ق' }],
  days: [0, 1, 2, 3, 4], start: '09:00', end: '17:00', slot: 30, example: false
};
function seed() {
  if (process.env.SANAD_SEED === '0' || Object.keys(users).length) return;
  const at = new Date().toISOString();
  const a = DEFAULTS.admin, c = DEFAULTS.client;
  users['u-owner'] = { id: 'u-owner', name: a.name, email: a.email, phone: a.phone, role: 'admin', super: true, seedPw: true, ...hashPw(a.password), createdAt: at };
  users['c-default'] = { id: 'c-default', name: c.name, email: c.email, phone: c.phone, role: 'client', seedPw: true, ...hashPw(c.password), createdAt: at };
  db['portal/c-default'] = { profile: { name: c.name, phone: c.phone, email: c.email }, bookings: [], updatedAt: at };
  if (!db['public/site']) db['public/site'] = { ...SITE_SEED, updatedAt: at };
  writeJSON('users.json', users); writeJSON('db.json', db); flush();
  fs.writeFileSync(file('default-accounts.txt'), [
    'سند | الحسابات الافتراضية (غيّر كلمات المرور بعد أول دخول من «لوحة التشغيل»)', '',
    `المدير الشامل: ${a.email}  أو  ${a.phone}`, `كلمة المرور: ${a.password}`, '',
    `العميل الافتراضي: ${c.email}  أو  ${c.phone}`, `كلمة المرور: ${c.password}`, ''
  ].join('\n'), { mode: 0o600 });
  console.log('  أُنشئت الحسابات الافتراضية في data/default-accounts.txt');
  console.log(`  المدير الشامل: ${a.email}  كلمة المرور: ${a.password}`);
  console.log(`  العميل الافتراضي: ${c.email}  كلمة المرور: ${c.password}`);
  console.log('  غيّرهما من «لوحة التشغيل» بعد أول دخول.');
}
seed(); ensureSetupCode();
const isSuper = u => !!(u && u.role === 'admin' && (u.super || !Object.values(users).some(x => x.super)));

/* ---------- rate limiting ---------- */
const buckets = new Map();
function limited(key, perHour) {
  const now = Date.now(), b = buckets.get(key) || [];
  const recent = b.filter(t => now - t < 36e5);
  if (recent.length >= perHour) { buckets.set(key, recent); return true; }
  recent.push(now); buckets.set(key, recent); return false;
}
const ip = req => (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

/* ---------- data rules ---------- */
const segs = p => String(p || '').split('/').filter(Boolean);
const validPath = p => typeof p === 'string' && /^[\w\-.:]+(\/[\w\-.:]+)*$/.test(p) && segs(p).every(s => s !== '..' && s !== '.');
function canRead(u, p) {
  if (u && u.role === 'admin') return true;
  if (p.startsWith('public/')) return true;
  return !!u && (p === `portal/${u.id}` || p.startsWith(`portal/${u.id}/`));
}
function canWrite(u, p) {
  if (u && u.role === 'admin') return true;
  return !!u && (p === `portal/${u.id}` || p.startsWith(`portal/${u.id}/`));
}
/* العميل لا يستطيع تأكيد حجزه بنفسه: يحتفظ الخادم بالحالة التي قررها المدير، ويسمح فقط بالإلغاء */
function guardPortal(u, p, next) {
  if (!u || u.role === 'admin' || p !== `portal/${u.id}` || !next || !Array.isArray(next.bookings)) return next;
  const prev = new Map(((db[p] && db[p].bookings) || []).map(b => [b.id, b]));
  next.bookings = next.bookings.map(b => {
    const o = prev.get(b.id);
    if (!o) { const { apptId, reason, ...rest } = b; return { ...rest, status: 'pending' }; }
    return { ...b, status: b.status === 'cancelled' && o.status !== 'cancelled' ? 'cancelled' : o.status, apptId: o.apptId, reason: o.reason };
  });
  return next;
}
let dbBytes = Buffer.byteLength(JSON.stringify(db));

/* ---------- live updates (Server-Sent Events) ---------- */
const streams = new Set();
function changed(p) {
  for (const s of streams) if (canRead(s.user && users[s.user.id], p)) s.res.write(`data: ${JSON.stringify({ path: p })}\n\n`);
}
setInterval(() => { for (const s of streams) s.res.write(': ping\n\n'); }, 25000).unref();

/* ---------- http helpers ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };
function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
const fail = (res, code, error, message) => send(res, code, { error, message });
function body(req, max = 12 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > max) { reject(Object.assign(new Error('too_large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(Object.assign(new Error('bad_json'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function serveStatic(req, res, pathname) {
  if (pathname === '/') pathname = '/index.html';
  if (pathname === '/setup') pathname = '/setup.html';
  if (pathname === '/login') pathname = '/login.html';
  if (pathname === '/admin') pathname = '/admin.html';
  const f = path.normalize(path.join(PUBLIC, decodeURIComponent(pathname)));
  if (!f.startsWith(PUBLIC)) return fail(res, 403, 'forbidden');
  fs.readFile(f, (err, buf) => {
    if (err) return fail(res, 404, 'not_found');
    const ext = path.extname(f);
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': ext === '.png' || ext === '.svg' ? 'public, max-age=86400' : 'no-cache',
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin',
      ...(pathname === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {})
    });
    res.end(buf);
  });
}

/* ---------- Claude ---------- */
const apiKey = () => process.env.ANTHROPIC_API_KEY || cfg.apiKey;
async function callClaude(payload) {
  const r = await fetch(AI_BASE + '/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': apiKey(), 'anthropic-version': '2023-06-01' },
    body: JSON.stringify(payload)
  });
  const text = await r.text(); let j; try { j = JSON.parse(text); } catch { j = { error: { message: text.slice(0, 300) } }; }
  return { status: r.status, json: j };
}

/* المساعد المدمج: يجيب من البيانات مباشرة عند غياب Claude، فلا تتوقف المحادثة أبداً */
function localAnswer(u, b, why) {
  const role = u ? u.role : 'visitor';
  const ctx = { role, name: u && u.name.split(' ')[0], site: db['public/site'] || {} };
  if (role === 'client') ctx.portal = db[`portal/${u.id}`];
  if (role === 'admin') {
    const day = Assistant.today();
    const appts = Object.keys(db).filter(k => k.startsWith('ops/main/appointments/')).map(k => db[k]);
    const portals = Object.keys(db).filter(k => /^portal\/[^/]+$/.test(k)).map(k => db[k]);
    ctx.admin = {
      today: appts.filter(a => a.date === day && a.status !== 'cancelled').sort((x, y) => String(x.time).localeCompare(String(y.time))).map(a => ({ time: a.time, title: a.title, client: a.clientName })),
      pending: portals.reduce((n, p) => n + ((p.bookings || []).filter(x => x.status === 'pending').length), 0),
      clients: Object.values(users).filter(x => x.role === 'client').length
    };
    ctx.note = why ? `ملاحظة: ${why} الرد من المساعد المدمج.` : 'ملاحظة: الرد من المساعد المدمج الذي يعمل دون Claude. لتفعيل الذكاء الكامل والأدوات أضف مفتاح Claude من «لوحة التشغيل» (اختياري).';
  }
  return Assistant.asMessage(Assistant.reply(Array.isArray(b.messages) ? b.messages : [], ctx));
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const p = url.pathname.slice(4); const m = req.method; const u = sessionUser(req);
  const role = u ? u.role : 'visitor';

  if (p === '/me' && m === 'GET') return send(res, 200, {
    version: VERSION, user: publicUser(u), role, needsSetup: !hasAdmin(),
    ai: { ready: true, claude: !!apiKey(), mode: apiKey() ? 'claude' : 'local', visitorChat: cfg.visitorChat }, registration: cfg.registration
  });

  if (p === '/setup' && m === 'POST') {
    if (hasAdmin()) return fail(res, 409, 'already_setup', 'اكتمل الإعداد مسبقاً. سجّل الدخول.');
    const b = await body(req);
    if (String(b.code || '').trim().toUpperCase() !== setupCode) return fail(res, 403, 'bad_code', 'رمز الإعداد غير صحيح. تجده في نافذة التشغيل أو في الملف data/setup-code.txt');
    const name = normName(b.name), email = normEmail(b.email);
    if (!name || !/^\S+@\S+\.\S+$/.test(email)) return fail(res, 400, 'invalid', 'الاسم والبريد الصحيح مطلوبان.');
    if (String(b.password || '').length < 8) return fail(res, 400, 'weak', 'كلمة المرور 8 أحرف على الأقل.');
    const id = 'u-' + crypto.randomBytes(6).toString('hex');
    users[id] = { id, name, email, phone: normPhone(b.phone), role: 'admin', ...hashPw(b.password), createdAt: new Date().toISOString() };
    if (b.apiKey) cfg.apiKey = String(b.apiKey).trim();
    if (MODELS[b.model]) cfg.model = b.model;
    saveUsers(); saveCfg(); ensureSetupCode(); startSession(res, req, users[id]);
    return send(res, 200, { ok: true, user: publicUser(users[id]) });
  }

  if (p === '/login' && m === 'POST') {
    if (limited('login:' + ip(req), 30)) return fail(res, 429, 'rate_limited', 'محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.');
    const b = await body(req); const x = findUser(b.login);
    if (!x || !checkPw(x, b.password || '')) return fail(res, 401, 'bad_login', 'بيانات الدخول غير صحيحة.');
    startSession(res, req, x); return send(res, 200, { ok: true, user: publicUser(x) });
  }
  if (p === '/register' && m === 'POST') {
    if (!cfg.registration) return fail(res, 403, 'closed', 'التسجيل مغلق حالياً. تواصل مع النشاط.');
    if (limited('reg:' + ip(req), 10)) return fail(res, 429, 'rate_limited', 'محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.');
    const b = await body(req); const name = normName(b.name), phone = normPhone(b.phone), email = normEmail(b.email);
    if (!name || digits(phone).length < 9) return fail(res, 400, 'invalid', 'الاسم ورقم الجوال مطلوبان.');
    if (email && !/^\S+@\S+\.\S+$/.test(email)) return fail(res, 400, 'invalid', 'صيغة البريد غير صحيحة.');
    if (String(b.password || '').length < 8) return fail(res, 400, 'weak', 'كلمة المرور 8 أحرف على الأقل.');
    if (findUser(phone) || (email && findUser(email))) return fail(res, 409, 'exists', 'يوجد حساب بهذا الجوال أو البريد. سجّل الدخول.');
    const id = 'c-' + crypto.randomBytes(6).toString('hex');
    users[id] = { id, name, phone, email, role: 'client', ...hashPw(b.password), createdAt: new Date().toISOString() };
    saveUsers();
    const doc = { profile: { name, phone, email }, bookings: [], updatedAt: new Date().toISOString() };
    db[`portal/${id}`] = doc; saveDb(); changed(`portal/${id}`);
    startSession(res, req, users[id]); return send(res, 200, { ok: true, user: publicUser(users[id]) });
  }
  if (p === '/logout' && m === 'POST') {
    const t = cookies(req).sanad_sid; if (t) { delete sessions[t]; saveSessions(); }
    res.setHeader('Set-Cookie', 'sanad_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
    return send(res, 200, { ok: true });
  }
  if (p === '/password' && m === 'POST') {
    if (!u) return fail(res, 401, 'auth');
    const b = await body(req);
    if (!checkPw(u, b.current || '')) return fail(res, 403, 'bad_login', 'كلمة المرور الحالية غير صحيحة.');
    if (String(b.password || '').length < 8) return fail(res, 400, 'weak', 'كلمة المرور 8 أحرف على الأقل.');
    Object.assign(u, hashPw(b.password)); delete u.seedPw; saveUsers(); return send(res, 200, { ok: true });
  }

  /* --- database --- */
  if (p === '/db/doc' || p === '/db/col') {
    const dp = url.searchParams.get('path');
    if (!validPath(dp)) return fail(res, 400, 'invalid_argument', 'مسار غير صالح');
    const n = segs(dp).length;
    if (p === '/db/col') {
      if (m !== 'GET' || n % 2 !== 1) return fail(res, 400, 'invalid_argument');
      const docs = Object.keys(db).filter(k => k.startsWith(dp + '/') && segs(k).length === n + 1 && canRead(u, k)).sort()
        .map(k => ({ id: segs(k).at(-1), data: db[k] }));
      return send(res, 200, { docs });
    }
    if (n % 2 !== 0) return fail(res, 400, 'invalid_argument');
    if (m === 'GET') return canRead(u, dp) ? send(res, 200, { exists: dp in db, data: db[dp] ?? null }) : send(res, 200, { exists: false, data: null });
    if (!canWrite(u, dp)) return fail(res, 403, 'invalid_argument', 'لا تملك صلاحية تنفيذ هذا الإجراء.');
    if (m === 'DELETE') { if (dp in db) { dbBytes -= Buffer.byteLength(JSON.stringify(db[dp])); delete db[dp]; saveDb(); changed(dp); } return send(res, 200, { ok: true }); }
    const b = await body(req, DOC_MAX * 2);
    if (!b || typeof b.data !== 'object' || Array.isArray(b.data)) return fail(res, 400, 'invalid_argument');
    let next;
    if (m === 'PUT') next = b.data;
    else if (m === 'PATCH') { if (!(dp in db)) return fail(res, 404, 'invalid_argument', 'المستند غير موجود'); next = { ...db[dp], ...b.data }; }
    else return fail(res, 405, 'method');
    next = guardPortal(u, dp, next);
    const size = Buffer.byteLength(JSON.stringify(next)), old = dp in db ? Buffer.byteLength(JSON.stringify(db[dp])) : 0;
    if (size > DOC_MAX || dbBytes - old + size > DB_MAX) return fail(res, 413, 'quota_exceeded');
    db[dp] = next; dbBytes += size - old; saveDb(); changed(dp);
    return send(res, 200, { ok: true });
  }
  if (p === '/events' && m === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write('retry: 3000\n\n');
    const s = { res, user: u }; streams.add(s); req.on('close', () => streams.delete(s));
    return;
  }

  /* --- Claude proxy (tools run in the browser under the same data rules) --- */
  if (p === '/ai' && m === 'POST') {
    if (role === 'visitor' && !cfg.visitorChat) return fail(res, 403, 'sampling_disabled');
    if (limited(`ai:${u ? u.id : ip(req)}`, cfg.limits[role] || 20)) return fail(res, 429, 'rate_limited');
    const b = await body(req);
    if (!apiKey()) return send(res, 200, localAnswer(u, b, ''));
    const tier = b.tier === 'quick' || role === 'visitor' ? 'haiku' : cfg.model;
    const payload = {
      model: MODELS[tier] || MODELS.sonnet,
      max_tokens: Math.min(Number(b.max_tokens) || 2048, role === 'admin' ? 8192 : 1500),
      messages: Array.isArray(b.messages) ? b.messages : []
    };
    if (typeof b.system === 'string' && b.system) payload.system = b.system;
    if (Array.isArray(b.tools) && b.tools.length) payload.tools = b.tools.slice(0, 24);
    try {
      const r = await callClaude(payload);
      if (r.status >= 400) {
        const why = r.status === 401 ? 'مفتاح Claude غير صالح، حدّثه من لوحة التشغيل.' : 'تعذّر الوصول إلى Claude مؤقتاً.';
        return send(res, 200, localAnswer(u, b, why));
      }
      return send(res, 200, r.json);
    } catch (e) { return send(res, 200, localAnswer(u, b, 'تعذّر الوصول إلى Claude مؤقتاً.')); }
  }

  /* --- admin console --- */
  if (p.startsWith('/admin/')) {
    if (!u || u.role !== 'admin') return fail(res, 403, 'invalid_argument', 'هذه الصفحة للمدير فقط.');
    const a = p.slice(7);
    if (a === 'settings' && m === 'GET') return send(res, 200, {
      model: cfg.model, models: MODELS, visitorChat: cfg.visitorChat, registration: cfg.registration, limits: cfg.limits,
      apiKey: apiKey() ? '••••' + apiKey().slice(-4) : '', apiKeyFromEnv: !!process.env.ANTHROPIC_API_KEY,
      super: isSuper(u), aiMode: apiKey() ? 'claude' : 'local',
      version: VERSION, dataDir: DATA, urls: lanUrls(), node: process.version, platform: `${os.platform()} ${os.arch()}`
    });
    if (a === 'settings' && m === 'POST') {
      const b = await body(req);
      if (typeof b.apiKey === 'string' && b.apiKey.trim()) cfg.apiKey = b.apiKey.trim();
      if (b.clearKey) cfg.apiKey = '';
      if (MODELS[b.model]) cfg.model = b.model;
      if (typeof b.visitorChat === 'boolean') cfg.visitorChat = b.visitorChat;
      if (typeof b.registration === 'boolean') cfg.registration = b.registration;
      if (b.limits) for (const k of ['visitor', 'client', 'admin']) if (Number(b.limits[k]) >= 0) cfg.limits[k] = Math.min(10000, Number(b.limits[k]));
      saveCfg(); return send(res, 200, { ok: true });
    }
    if (a === 'test-ai' && m === 'POST') {
      if (!apiKey()) return fail(res, 503, 'not_configured', 'أدخل مفتاح Claude أولاً.');
      try {
        const r = await callClaude({ model: MODELS.haiku, max_tokens: 20, messages: [{ role: 'user', content: 'أجب بكلمة واحدة: جاهز' }] });
        if (r.status >= 400) return fail(res, 502, 'ai_error', r.status === 401 ? 'المفتاح غير صالح.' : (r.json.error && r.json.error.message) || 'خطأ من Claude');
        return send(res, 200, { ok: true, reply: (r.json.content || []).map(c => c.text || '').join('').trim() });
      } catch { return fail(res, 502, 'ai_unreachable', 'تعذّر الوصول إلى Claude. تحقق من الاتصال.'); }
    }
    if (a === 'users' && m === 'GET') return send(res, 200, { users: Object.values(users).map(publicUser).sort((x, y) => String(y.createdAt).localeCompare(String(x.createdAt))) });
    if (a === 'users' && m === 'POST') {
      const b = await body(req); const name = normName(b.name), email = normEmail(b.email), phone = normPhone(b.phone);
      const r = b.role === 'admin' ? 'admin' : 'client';
      if (r === 'admin' && !isSuper(u)) return fail(res, 403, 'forbidden', 'إضافة المديرين للمدير الشامل فقط.');
      if (!name || (!email && digits(phone).length < 9)) return fail(res, 400, 'invalid', 'الاسم مع البريد أو الجوال مطلوب.');
      if (String(b.password || '').length < 8) return fail(res, 400, 'weak', 'كلمة المرور 8 أحرف على الأقل.');
      if ((email && findUser(email)) || (phone && findUser(phone))) return fail(res, 409, 'exists', 'يوجد حساب بهذه البيانات.');
      const id = (r === 'admin' ? 'u-' : 'c-') + crypto.randomBytes(6).toString('hex');
      users[id] = { id, name, email, phone, role: r, ...hashPw(b.password), createdAt: new Date().toISOString() };
      saveUsers(); return send(res, 200, { ok: true, user: publicUser(users[id]) });
    }
    if (a.startsWith('users/') && m === 'DELETE') {
      const id = a.slice(6); if (!users[id]) return fail(res, 404, 'not_found');
      if (id === u.id) return fail(res, 400, 'self', 'لا يمكنك حذف حسابك الحالي.');
      if (users[id].super) return fail(res, 403, 'forbidden', 'لا يمكن حذف حساب المدير الشامل.');
      if (users[id].role === 'admin' && !isSuper(u)) return fail(res, 403, 'forbidden', 'حذف المديرين للمدير الشامل فقط.');
      delete users[id]; for (const [k, v] of Object.entries(sessions)) if (v.uid === id) delete sessions[k];
      saveUsers(); saveSessions(); return send(res, 200, { ok: true });
    }
    if (a === 'backup' && m === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Disposition': `attachment; filename="sanad-backup-${new Date().toISOString().slice(0, 10)}.json"` });
      const { apiKey: _k, secret: _s, ...safeCfg } = cfg;
      return res.end(JSON.stringify({ app: 'sanad', version: VERSION, at: new Date().toISOString(), config: safeCfg, users, db }));
    }
    if (a === 'restore' && m === 'POST') {
      if (!isSuper(u)) return fail(res, 403, 'forbidden', 'استعادة النسخ للمدير الشامل فقط.');
      const b = await body(req, 60 * 1024 * 1024);
      if (!b || b.app !== 'sanad' || typeof b.db !== 'object' || typeof b.users !== 'object') return fail(res, 400, 'invalid', 'ملف النسخة غير صالح.');
      if (!Object.values(b.users).some(x => x.role === 'admin')) return fail(res, 400, 'invalid', 'النسخة لا تحتوي حساب مدير.');
      for (const k of Object.keys(db)) delete db[k]; Object.assign(db, b.db);
      for (const k of Object.keys(users)) delete users[k]; Object.assign(users, b.users);
      if (b.config) for (const k of ['model', 'visitorChat', 'registration', 'limits']) if (k in b.config) cfg[k] = b.config[k];
      dbBytes = Buffer.byteLength(JSON.stringify(db)); saveDb(); saveUsers(); saveCfg();
      for (const k of Object.keys(db)) changed(k);
      return send(res, 200, { ok: true, docs: Object.keys(db).length, users: Object.keys(users).length });
    }
  }
  return fail(res, 404, 'not_found');
}

function lanUrls() {
  const out = [`http://localhost:${PORT}`];
  for (const list of Object.values(os.networkInterfaces())) for (const n of list || [])
    if (n.family === 'IPv4' && !n.internal) out.push(`http://${n.address}:${PORT}`);
  return out;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        const o = req.headers.origin; // حماية من الطلبات المزوّرة من مواقع أخرى
        if (o && new URL(o).host !== req.headers.host) return fail(res, 403, 'bad_origin');
      }
      return await api(req, res, url);
    }
    if (url.pathname === '/healthz') return send(res, 200, { ok: true, version: VERSION });
    if (!hasAdmin() && (url.pathname === '/' || url.pathname === '/index.html')) { res.writeHead(302, { Location: '/setup' + url.search }); return res.end(); }
    return serveStatic(req, res, url.pathname);
  } catch (e) {
    if (!res.headersSent) fail(res, e.status || 500, e.message === 'too_large' ? 'quota_exceeded' : 'server_error', e.status ? undefined : 'خطأ داخلي');
    if (!e.status) console.error(e);
  }
});
const EN = (process.env.SANAD_LANG || (process.platform === 'win32' ? 'en' : 'ar')) === 'en';
const T = (ar, en) => (EN ? en : ar);
server.listen(PORT, HOST, () => {
  const urls = lanUrls();
  console.log('\n  ==============================================');
  console.log(T(`   سند | Sanad ${VERSION} يعمل الآن`, `   Sanad ${VERSION} is running`));
  console.log('  ==============================================');
  console.log(T('  على هذا الجهاز: ', '  On this device:  ') + urls[0]);
  if (urls[1]) console.log(T('  من الجوال (نفس الشبكة): ', '  From your phone (same Wi-Fi): ') + urls.slice(1).join('  '));
  if (setupCode) console.log(T(`\n  الإعداد الأول: ${urls[0]}/setup?code=${setupCode}\n  رمز الإعداد: ${setupCode}`, `\n  First-time setup: ${urls[0]}/setup?code=${setupCode}\n  Setup code: ${setupCode}`));
  console.log(T('  البيانات محفوظة في: ', '  Data folder: ') + DATA);
  console.log(T('  للإيقاف: Ctrl + C أو أغلق هذه النافذة\n', '  To stop: press Ctrl + C or close this window\n'));
  if (process.env.SANAD_READY_FILE) fs.writeFileSync(process.env.SANAD_READY_FILE, urls[0] + (setupCode ? `/setup?code=${setupCode}` : ''));
});
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(T(`\n  المنفذ ${PORT} مستخدم. ربما سند يعمل بالفعل: افتح http://localhost:${PORT}\n  أو شغّل على منفذ آخر: PORT=8788\n`, `\n  Port ${PORT} is busy. Sanad may already be running: open http://localhost:${PORT}\n  Or use another port: set PORT=8788\n`));
  else console.error(e);
  process.exit(1);
});
