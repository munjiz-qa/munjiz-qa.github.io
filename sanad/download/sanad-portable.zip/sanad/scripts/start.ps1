﻿# =====================================================================
#  Sanad (سند) - Windows launcher
#  Finds Node.js 18+, or downloads a portable copy into the Sanad folder
#  (nothing is installed system-wide), starts Sanad and opens the browser.
#    Start-Sanad-Windows.bat              start + open browser
#    Start-Sanad-Windows.bat -Install     desktop shortcut + start with Windows
#    Start-Sanad-Windows.bat -Uninstall   remove shortcut + autostart
# =====================================================================
param([switch]$Install, [switch]$Uninstall, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$NodeVersion = '22.22.0'
$App = Split-Path -Parent $PSScriptRoot
if (-not $env:PORT) { $env:PORT = '8787' }
$Port = $env:PORT
$env:SANAD_LANG = 'en'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

function Say($t) { Write-Host "> $t" -ForegroundColor Cyan }
function NodeOk($exe) {
  try { $v = & $exe -p "process.versions.node.split('.')[0]" 2>$null; return ([int]$v -ge 18) } catch { return $false }
}
function Find-Node {
  $local = Join-Path $App 'runtime\node\node.exe'
  if ((Test-Path $local) -and (NodeOk $local)) { return $local }
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd -and (NodeOk $cmd.Source)) { return $cmd.Source }
  return $null
}
function Install-Node {
  $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
  $name = "node-v$NodeVersion-win-$arch"
  $rt = Join-Path $App 'runtime'; New-Item -ItemType Directory -Force -Path $rt | Out-Null
  $zip = Join-Path $rt 'node.zip'
  Say "Downloading portable Node.js $NodeVersion ($arch) into the Sanad folder (one time only)..."
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $ProgressPreference = 'SilentlyContinue'
  Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/v$NodeVersion/$name.zip" -OutFile $zip
  if (Test-Path (Join-Path $rt 'node')) { Remove-Item -Recurse -Force (Join-Path $rt 'node') }
  Expand-Archive -Path $zip -DestinationPath $rt -Force
  Rename-Item -Path (Join-Path $rt $name) -NewName 'node'
  Remove-Item $zip
  return (Join-Path $rt 'node\node.exe')
}
function Shortcut($path) {
  $s = (New-Object -ComObject WScript.Shell).CreateShortcut($path)
  $s.TargetPath = Join-Path $App 'Start-Sanad-Windows.bat'
  $s.WorkingDirectory = $App
  $s.IconLocation = Join-Path $App 'public\icons\sanad.ico'
  $s.WindowStyle = 7
  $s.Description = 'Sanad'
  $s.Save()
}
function Test-Running {
  try { return (Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 "http://127.0.0.1:$Port/healthz").StatusCode -eq 200 } catch { return $false }
}

function LinkIn($folder) { $d = [Environment]::GetFolderPath($folder); if ($d) { return (Join-Path $d 'Sanad.lnk') } else { return $null } }
$desk = LinkIn 'Desktop'
$boot = LinkIn 'Startup'
if ($Uninstall) { foreach ($l in @($desk, $boot)) { if ($l) { Remove-Item -Force $l -ErrorAction SilentlyContinue } }; Say 'Shortcut and autostart removed.'; exit 0 }

$node = Find-Node
if (-not $node) { $node = Install-Node }
if (-not (NodeOk $node)) { Write-Host 'Node.js 18+ is required. Install it from https://nodejs.org and try again.' -ForegroundColor Red; exit 1 }

if ($desk -and ($Install -or -not (Test-Path $desk))) { try { Shortcut $desk; Say 'Desktop shortcut "Sanad" created.' } catch {} }
if ($Install -and $boot) { try { Shortcut $boot; Say 'Sanad will start automatically with Windows.' } catch { Say 'Could not create the autostart shortcut.' } }

if (Test-Running) { Say 'Sanad is already running.'; if (-not $NoBrowser) { Start-Process "http://localhost:$Port" }; exit 0 }

$ready = Join-Path $App 'runtime\.ready'
New-Item -ItemType Directory -Force -Path (Split-Path $ready) | Out-Null
Remove-Item $ready -ErrorAction SilentlyContinue
$env:SANAD_READY_FILE = $ready
if (-not $NoBrowser) {
  Start-Job -ArgumentList $ready -ScriptBlock {
    param($f) for ($i = 0; $i -lt 60; $i++) { if ((Test-Path $f) -and (Get-Item $f).Length -gt 0) { Start-Process (Get-Content $f -Raw).Trim(); break }; Start-Sleep -Milliseconds 500 }
  } | Out-Null
}
Say 'Starting Sanad... keep this window open while you use it.'
& $node (Join-Path $App 'server.js')
