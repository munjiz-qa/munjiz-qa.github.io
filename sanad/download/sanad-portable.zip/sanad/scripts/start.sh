#!/bin/sh
# =====================================================================
#  سند | Sanad — التشغيل على ماك ولينكس وأندرويد (Termux)
#  يبحث عن Node.js 18+، وإن لم يجده ينزّل نسخة محمولة داخل مجلد سند فقط
#  (لا يغيّر شيئاً في النظام)، ثم يشغّل سند ويفتح المتصفح.
#
#  ./start.sh            تشغيل وفتح المتصفح
#  ./start.sh --service  تشغيل تلقائي مع بدء الجهاز (systemd أو launchd)
#  ./start.sh --remove-service  إلغاء التشغيل التلقائي
#  ./start.sh --no-browser      تشغيل دون فتح المتصفح (للخوادم)
# =====================================================================
set -eu
NODE_VERSION="22.22.0"
cd "$(dirname "$0")/.."
APP="$(pwd)"
PORT="${PORT:-8787}"
export PORT

say() { printf '\033[1;36m▸ %s\033[0m\n' "$*"; }
die() { printf '\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

node_ok() { [ -x "$1" ] || command -v "$1" >/dev/null 2>&1 || return 1; v=$("$1" -p 'process.versions.node.split(".")[0]' 2>/dev/null) || return 1; [ "${v:-0}" -ge 18 ]; }

find_node() {
  if [ -x "$APP/runtime/node/bin/node" ] && node_ok "$APP/runtime/node/bin/node"; then NODE="$APP/runtime/node/bin/node"; return 0; fi
  if node_ok node; then NODE="$(command -v node)"; return 0; fi
  return 1
}

fetch() { if command -v curl >/dev/null 2>&1; then curl -fL --progress-bar "$1" -o "$2"; elif command -v wget >/dev/null 2>&1; then wget -q --show-progress -O "$2" "$1"; else die "curl أو wget مطلوب لتنزيل Node.js"; fi; }

install_node() {
  case "${PREFIX:-}" in *com.termux*)
    say "أندرويد (Termux): تثبيت Node.js"; pkg install -y nodejs-lts >/dev/null 2>&1 || pkg install -y nodejs; NODE="$(command -v node)"; return 0;; esac
  os=$(uname -s); arch=$(uname -m)
  case "$os" in Linux) os=linux;; Darwin) os=darwin;; *) die "نظام غير مدعوم: $os";; esac
  case "$arch" in x86_64|amd64) arch=x64;; aarch64|arm64) arch=arm64;; armv7l|armv7) arch=armv7l;; *) die "معالج غير مدعوم: $arch";; esac
  name="node-v$NODE_VERSION-$os-$arch"
  say "تنزيل Node.js $NODE_VERSION المحمول ($os-$arch) داخل مجلد سند، لمرة واحدة فقط…"
  mkdir -p "$APP/runtime"; tmp="$APP/runtime/node.tar.gz"
  fetch "https://nodejs.org/dist/v$NODE_VERSION/$name.tar.gz" "$tmp" || die "تعذّر التنزيل. تحقق من الإنترنت أو ثبّت Node.js من nodejs.org"
  rm -rf "$APP/runtime/node" "$APP/runtime/$name"; tar -xzf "$tmp" -C "$APP/runtime"; mv "$APP/runtime/$name" "$APP/runtime/node"; rm -f "$tmp"
  NODE="$APP/runtime/node/bin/node"
}

open_url() {
  case "${PREFIX:-}" in *com.termux*) termux-open-url "$1" >/dev/null 2>&1 && return;; esac
  if command -v open >/dev/null 2>&1 && [ "$(uname -s)" = Darwin ]; then open "$1"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$1" >/dev/null 2>&1 &
  else printf '  افتح في المتصفح: %s\n' "$1"; fi
}

running() { "$NODE" -e "fetch('http://127.0.0.1:$PORT/healthz').then(r=>process.exit(r.ok?0:1),()=>process.exit(1))" 2>/dev/null; }

find_node || install_node
node_ok "$NODE" || die "Node.js 18 أو أحدث مطلوب"

case "${1:-}" in
  --service)
    if [ "$(uname -s)" = Darwin ]; then
      pl="$HOME/Library/LaunchAgents/sa.sanad.app.plist"; mkdir -p "$(dirname "$pl")"
      cat > "$pl" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>sa.sanad.app</string>
<key>ProgramArguments</key><array><string>$NODE</string><string>$APP/server.js</string></array>
<key>EnvironmentVariables</key><dict><key>PORT</key><string>$PORT</string></dict>
<key>WorkingDirectory</key><string>$APP</string>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>StandardOutPath</key><string>$APP/data/sanad.log</string><key>StandardErrorPath</key><string>$APP/data/sanad.log</string>
</dict></plist>
PL
      mkdir -p "$APP/data"; launchctl unload "$pl" 2>/dev/null || true; launchctl load "$pl"
      say "سيعمل سند تلقائياً مع تشغيل الماك. العنوان: http://localhost:$PORT"; exit 0
    fi
    command -v systemctl >/dev/null 2>&1 || die "systemd غير متاح على هذا النظام"
    unit="[Unit]
Description=Sanad | سند
After=network-online.target
[Service]
WorkingDirectory=$APP
Environment=PORT=$PORT
ExecStart=$NODE $APP/server.js
Restart=always
RestartSec=3
[Install]
WantedBy=default.target"
    if [ "$(id -u)" -eq 0 ]; then
      printf '%s\n' "$unit" | sed 's/WantedBy=default.target/WantedBy=multi-user.target/' > /etc/systemd/system/sanad.service
      systemctl daemon-reload; systemctl enable --now sanad
    else
      mkdir -p "$HOME/.config/systemd/user"; printf '%s\n' "$unit" > "$HOME/.config/systemd/user/sanad.service"
      systemctl --user daemon-reload; systemctl --user enable --now sanad
      loginctl enable-linger "$(id -un)" 2>/dev/null || true
    fi
    sleep 2; cat "$APP/data/setup-code.txt" 2>/dev/null | sed 's/^/  رمز الإعداد: /' || true
    say "سيعمل سند تلقائياً مع تشغيل الجهاز. العنوان: http://localhost:$PORT"; exit 0;;
  --remove-service)
    if [ "$(uname -s)" = Darwin ]; then pl="$HOME/Library/LaunchAgents/sa.sanad.app.plist"; launchctl unload "$pl" 2>/dev/null || true; rm -f "$pl"
    elif [ "$(id -u)" -eq 0 ]; then systemctl disable --now sanad 2>/dev/null || true; rm -f /etc/systemd/system/sanad.service; systemctl daemon-reload
    else systemctl --user disable --now sanad 2>/dev/null || true; rm -f "$HOME/.config/systemd/user/sanad.service"; fi
    say "أُلغي التشغيل التلقائي"; exit 0;;
esac

if running; then say "سند يعمل بالفعل"; [ "${1:-}" = "--no-browser" ] || open_url "http://localhost:$PORT"; exit 0; fi

READY="$APP/runtime/.ready"; mkdir -p "$APP/runtime"; rm -f "$READY"
export SANAD_READY_FILE="$READY"
if [ "${1:-}" != "--no-browser" ]; then
  ( i=0; while [ $i -lt 60 ] && [ ! -s "$READY" ]; do sleep 0.5; i=$((i+1)); done; [ -s "$READY" ] && open_url "$(cat "$READY")" ) &
fi
exec "$NODE" "$APP/server.js"
