@echo off
rem Sanad - double-click to start on Windows
title Sanad
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1" %*
if errorlevel 1 pause
