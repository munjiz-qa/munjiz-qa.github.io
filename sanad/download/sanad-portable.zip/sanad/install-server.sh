#!/usr/bin/env bash
# =====================================================================
#  سند | Sanad — تثبيت على خادم لينكس (VPS) بأمر واحد، مع HTTPS تلقائي
#    sudo bash install-server.sh --domain agent.example.com
#    sudo bash install-server.sh            (دون نطاق: على المنفذ 8787)
# =====================================================================
set -euo pipefail
DOMAIN=""; DEST=/opt/sanad-app
while [ $# -gt 0 ]; do case "$1" in --domain) DOMAIN="$2"; shift 2;; --dir) DEST="$2"; shift 2;; *) echo "خيار غير معروف: $1"; exit 1;; esac; done
[ "$(id -u)" -eq 0 ] || { echo "شغّل بصلاحية root (sudo)"; exit 1; }
say() { printf '\n\033[1;36m▸ %s\033[0m\n' "$*"; }
SRC="$(cd "$(dirname "$0")" && pwd)"
say "1/4 Docker"
command -v docker >/dev/null || { curl -fsSL https://get.docker.com | sh >/dev/null; }
docker compose version >/dev/null
say "2/4 نسخ الملفات إلى $DEST"
mkdir -p "$DEST"; [ "$SRC" = "$DEST" ] || cp -r "$SRC/server.js" "$SRC/public" "$SRC/Dockerfile" "$SRC/docker-compose.yml" "$SRC/.dockerignore" "$DEST/"
cd "$DEST"
# على خادم متاح من الإنترنت تُولَّد كلمات مرور عشوائية قوية للحسابات الافتراضية (مرة واحدة)
PW() { tr -dc 'A-Za-z0-9' </dev/urandom | head -c 14; }
OLD_A=$(grep -s '^SANAD_ADMIN_PASSWORD=' .env | cut -d= -f2- || true); OLD_C=$(grep -s '^SANAD_CLIENT_PASSWORD=' .env | cut -d= -f2- || true)
{ echo "DOMAIN=${DOMAIN:-localhost}"; [ -n "$DOMAIN" ] && echo "SANAD_BIND=127.0.0.1"
  echo "SANAD_ADMIN_PASSWORD=${OLD_A:-Sa@$(PW)}"; echo "SANAD_CLIENT_PASSWORD=${OLD_C:-Cl@$(PW)}"; } > .env
chmod 600 .env
if command -v ufw >/dev/null && ufw status | grep -q active; then
  if [ -n "$DOMAIN" ]; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; else ufw allow 8787/tcp >/dev/null; fi
fi
say "3/4 تشغيل سند"
if [ -n "$DOMAIN" ]; then docker compose --profile https up -d --build; else docker compose up -d --build; fi
say "4/4 انتظار الجاهزية"
for i in $(seq 1 60); do docker compose exec -T sanad wget -qO- http://127.0.0.1:8787/healthz >/dev/null 2>&1 && break; sleep 1; done
CODE=$(docker compose exec -T sanad cat /data/setup-code.txt 2>/dev/null | tr -d '\r\n' || true)
ACCTS=$(docker compose exec -T sanad cat /data/default-accounts.txt 2>/dev/null || true)
URL=$([ -n "$DOMAIN" ] && echo "https://$DOMAIN" || echo "http://$(hostname -I | awk '{print $1}'):8787")
echo
echo "  ✓ سند يعمل: $URL"
[ -n "$CODE" ] && echo "  ✓ الإعداد الأول: $URL/setup?code=$CODE   (رمز الإعداد: $CODE)"
[ -n "$ACCTS" ] && { echo; echo "$ACCTS" | sed 's/^/  /'; }
echo "  التحديث لاحقاً: cd $DEST && docker compose up -d --build"
echo "  السجلات:        cd $DEST && docker compose logs -f sanad"
